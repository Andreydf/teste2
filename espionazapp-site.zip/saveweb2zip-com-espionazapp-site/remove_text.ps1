$content = Get-Content -Path "index.html" -Raw
$newContent = $content -replace '<p style="color: #e93535; font-size: 22px; font-weight: 700; width: 100%; text-align: center; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 0.5px;">\s*ESTA FERRAMENTA É 100% ANÔNIMA\s*</p>', ''
$newContent = $newContent -replace '<div style="width: 100px; height: 3px; background: #e93535; margin: 10px auto 0;"></div>', ''
$newContent | Set-Content -Path "index.html"
Write-Host "Texto removido com sucesso!" 