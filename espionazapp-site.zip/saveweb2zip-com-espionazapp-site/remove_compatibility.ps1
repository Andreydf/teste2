$content = Get-Content -Path "index.html" -Raw
$startPattern = '<section id="compatibility-section"'
$endPattern = '</section>'

$startIndex = $content.IndexOf($startPattern)
if ($startIndex -ge 0) {
    $endIndex = $content.IndexOf($endPattern, $startIndex) + $endPattern.Length
    $sectionToRemove = $content.Substring($startIndex, $endIndex - $startIndex)
    $newContent = $content.Replace($sectionToRemove, "")
    $newContent | Set-Content -Path "index.html"
    Write-Host "Seção de compatibilidade removida com sucesso!"
} else {
    Write-Host "Seção de compatibilidade não encontrada."
} 